
# Read the Datafile


```python
import pandas as pd
import numpy as np
star_wars = pd.read_csv("./databank/StarWars.csv", encoding="ISO-8859-1")
star_wars.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RespondentID</th>
      <th>Have you seen any of the 6 films in the Star Wars franchise?</th>
      <th>Do you consider yourself to be a fan of the Star Wars film franchise?</th>
      <th>Which of the following Star Wars films have you seen? Please select all that apply.</th>
      <th>Unnamed: 4</th>
      <th>Unnamed: 5</th>
      <th>Unnamed: 6</th>
      <th>Unnamed: 7</th>
      <th>Unnamed: 8</th>
      <th>Please rank the Star Wars films in order of preference with 1 being your favorite film in the franchise and 6 being your least favorite film.</th>
      <th>...</th>
      <th>Unnamed: 28</th>
      <th>Which character shot first?</th>
      <th>Are you familiar with the Expanded Universe?</th>
      <th>Do you consider yourself to be a fan of the Expanded Universe?æ</th>
      <th>Do you consider yourself to be a fan of the Star Trek franchise?</th>
      <th>Gender</th>
      <th>Age</th>
      <th>Household Income</th>
      <th>Education</th>
      <th>Location (Census Region)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>NaN</td>
      <td>Response</td>
      <td>Response</td>
      <td>Star Wars: Episode I  The Phantom Menace</td>
      <td>Star Wars: Episode II  Attack of the Clones</td>
      <td>Star Wars: Episode III  Revenge of the Sith</td>
      <td>Star Wars: Episode IV  A New Hope</td>
      <td>Star Wars: Episode V The Empire Strikes Back</td>
      <td>Star Wars: Episode VI Return of the Jedi</td>
      <td>Star Wars: Episode I  The Phantom Menace</td>
      <td>...</td>
      <td>Yoda</td>
      <td>Response</td>
      <td>Response</td>
      <td>Response</td>
      <td>Response</td>
      <td>Response</td>
      <td>Response</td>
      <td>Response</td>
      <td>Response</td>
      <td>Response</td>
    </tr>
    <tr>
      <th>1</th>
      <td>3292879998</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>Star Wars: Episode I  The Phantom Menace</td>
      <td>Star Wars: Episode II  Attack of the Clones</td>
      <td>Star Wars: Episode III  Revenge of the Sith</td>
      <td>Star Wars: Episode IV  A New Hope</td>
      <td>Star Wars: Episode V The Empire Strikes Back</td>
      <td>Star Wars: Episode VI Return of the Jedi</td>
      <td>3</td>
      <td>...</td>
      <td>Very favorably</td>
      <td>I don't understand this question</td>
      <td>Yes</td>
      <td>No</td>
      <td>No</td>
      <td>Male</td>
      <td>18-29</td>
      <td>NaN</td>
      <td>High school degree</td>
      <td>South Atlantic</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3292879538</td>
      <td>No</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Yes</td>
      <td>Male</td>
      <td>18-29</td>
      <td>$0 - $24,999</td>
      <td>Bachelor degree</td>
      <td>West South Central</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3292765271</td>
      <td>Yes</td>
      <td>No</td>
      <td>Star Wars: Episode I  The Phantom Menace</td>
      <td>Star Wars: Episode II  Attack of the Clones</td>
      <td>Star Wars: Episode III  Revenge of the Sith</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>...</td>
      <td>Unfamiliar (N/A)</td>
      <td>I don't understand this question</td>
      <td>No</td>
      <td>NaN</td>
      <td>No</td>
      <td>Male</td>
      <td>18-29</td>
      <td>$0 - $24,999</td>
      <td>High school degree</td>
      <td>West North Central</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3292763116</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>Star Wars: Episode I  The Phantom Menace</td>
      <td>Star Wars: Episode II  Attack of the Clones</td>
      <td>Star Wars: Episode III  Revenge of the Sith</td>
      <td>Star Wars: Episode IV  A New Hope</td>
      <td>Star Wars: Episode V The Empire Strikes Back</td>
      <td>Star Wars: Episode VI Return of the Jedi</td>
      <td>5</td>
      <td>...</td>
      <td>Very favorably</td>
      <td>I don't understand this question</td>
      <td>No</td>
      <td>NaN</td>
      <td>Yes</td>
      <td>Male</td>
      <td>18-29</td>
      <td>$100,000 - $149,999</td>
      <td>Some college or Associate degree</td>
      <td>West North Central</td>
    </tr>
    <tr>
      <th>5</th>
      <td>3292731220</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>Star Wars: Episode I  The Phantom Menace</td>
      <td>Star Wars: Episode II  Attack of the Clones</td>
      <td>Star Wars: Episode III  Revenge of the Sith</td>
      <td>Star Wars: Episode IV  A New Hope</td>
      <td>Star Wars: Episode V The Empire Strikes Back</td>
      <td>Star Wars: Episode VI Return of the Jedi</td>
      <td>5</td>
      <td>...</td>
      <td>Somewhat favorably</td>
      <td>Greedo</td>
      <td>Yes</td>
      <td>No</td>
      <td>No</td>
      <td>Male</td>
      <td>18-29</td>
      <td>$100,000 - $149,999</td>
      <td>Some college or Associate degree</td>
      <td>West North Central</td>
    </tr>
    <tr>
      <th>6</th>
      <td>3292719380</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>Star Wars: Episode I  The Phantom Menace</td>
      <td>Star Wars: Episode II  Attack of the Clones</td>
      <td>Star Wars: Episode III  Revenge of the Sith</td>
      <td>Star Wars: Episode IV  A New Hope</td>
      <td>Star Wars: Episode V The Empire Strikes Back</td>
      <td>Star Wars: Episode VI Return of the Jedi</td>
      <td>1</td>
      <td>...</td>
      <td>Very favorably</td>
      <td>Han</td>
      <td>Yes</td>
      <td>No</td>
      <td>Yes</td>
      <td>Male</td>
      <td>18-29</td>
      <td>$25,000 - $49,999</td>
      <td>Bachelor degree</td>
      <td>Middle Atlantic</td>
    </tr>
    <tr>
      <th>7</th>
      <td>3292684787</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>Star Wars: Episode I  The Phantom Menace</td>
      <td>Star Wars: Episode II  Attack of the Clones</td>
      <td>Star Wars: Episode III  Revenge of the Sith</td>
      <td>Star Wars: Episode IV  A New Hope</td>
      <td>Star Wars: Episode V The Empire Strikes Back</td>
      <td>Star Wars: Episode VI Return of the Jedi</td>
      <td>6</td>
      <td>...</td>
      <td>Very favorably</td>
      <td>Han</td>
      <td>Yes</td>
      <td>No</td>
      <td>No</td>
      <td>Male</td>
      <td>18-29</td>
      <td>NaN</td>
      <td>High school degree</td>
      <td>East North Central</td>
    </tr>
    <tr>
      <th>8</th>
      <td>3292663732</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>Star Wars: Episode I  The Phantom Menace</td>
      <td>Star Wars: Episode II  Attack of the Clones</td>
      <td>Star Wars: Episode III  Revenge of the Sith</td>
      <td>Star Wars: Episode IV  A New Hope</td>
      <td>Star Wars: Episode V The Empire Strikes Back</td>
      <td>Star Wars: Episode VI Return of the Jedi</td>
      <td>4</td>
      <td>...</td>
      <td>Very favorably</td>
      <td>Han</td>
      <td>No</td>
      <td>NaN</td>
      <td>Yes</td>
      <td>Male</td>
      <td>18-29</td>
      <td>NaN</td>
      <td>High school degree</td>
      <td>South Atlantic</td>
    </tr>
    <tr>
      <th>9</th>
      <td>3292654043</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>Star Wars: Episode I  The Phantom Menace</td>
      <td>Star Wars: Episode II  Attack of the Clones</td>
      <td>Star Wars: Episode III  Revenge of the Sith</td>
      <td>Star Wars: Episode IV  A New Hope</td>
      <td>Star Wars: Episode V The Empire Strikes Back</td>
      <td>Star Wars: Episode VI Return of the Jedi</td>
      <td>5</td>
      <td>...</td>
      <td>Somewhat favorably</td>
      <td>Han</td>
      <td>No</td>
      <td>NaN</td>
      <td>No</td>
      <td>Male</td>
      <td>18-29</td>
      <td>$0 - $24,999</td>
      <td>Some college or Associate degree</td>
      <td>South Atlantic</td>
    </tr>
  </tbody>
</table>
<p>10 rows × 38 columns</p>
</div>



# Removing the RespondentID Irregularities


```python
star_wars = star_wars[pd.notnull(star_wars["RespondentID"])]
star_wars.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RespondentID</th>
      <th>Have you seen any of the 6 films in the Star Wars franchise?</th>
      <th>Do you consider yourself to be a fan of the Star Wars film franchise?</th>
      <th>Which of the following Star Wars films have you seen? Please select all that apply.</th>
      <th>Unnamed: 4</th>
      <th>Unnamed: 5</th>
      <th>Unnamed: 6</th>
      <th>Unnamed: 7</th>
      <th>Unnamed: 8</th>
      <th>Please rank the Star Wars films in order of preference with 1 being your favorite film in the franchise and 6 being your least favorite film.</th>
      <th>...</th>
      <th>Unnamed: 28</th>
      <th>Which character shot first?</th>
      <th>Are you familiar with the Expanded Universe?</th>
      <th>Do you consider yourself to be a fan of the Expanded Universe?æ</th>
      <th>Do you consider yourself to be a fan of the Star Trek franchise?</th>
      <th>Gender</th>
      <th>Age</th>
      <th>Household Income</th>
      <th>Education</th>
      <th>Location (Census Region)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>3292879998</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>Star Wars: Episode I  The Phantom Menace</td>
      <td>Star Wars: Episode II  Attack of the Clones</td>
      <td>Star Wars: Episode III  Revenge of the Sith</td>
      <td>Star Wars: Episode IV  A New Hope</td>
      <td>Star Wars: Episode V The Empire Strikes Back</td>
      <td>Star Wars: Episode VI Return of the Jedi</td>
      <td>3</td>
      <td>...</td>
      <td>Very favorably</td>
      <td>I don't understand this question</td>
      <td>Yes</td>
      <td>No</td>
      <td>No</td>
      <td>Male</td>
      <td>18-29</td>
      <td>NaN</td>
      <td>High school degree</td>
      <td>South Atlantic</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3292879538</td>
      <td>No</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Yes</td>
      <td>Male</td>
      <td>18-29</td>
      <td>$0 - $24,999</td>
      <td>Bachelor degree</td>
      <td>West South Central</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3292765271</td>
      <td>Yes</td>
      <td>No</td>
      <td>Star Wars: Episode I  The Phantom Menace</td>
      <td>Star Wars: Episode II  Attack of the Clones</td>
      <td>Star Wars: Episode III  Revenge of the Sith</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>...</td>
      <td>Unfamiliar (N/A)</td>
      <td>I don't understand this question</td>
      <td>No</td>
      <td>NaN</td>
      <td>No</td>
      <td>Male</td>
      <td>18-29</td>
      <td>$0 - $24,999</td>
      <td>High school degree</td>
      <td>West North Central</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3292763116</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>Star Wars: Episode I  The Phantom Menace</td>
      <td>Star Wars: Episode II  Attack of the Clones</td>
      <td>Star Wars: Episode III  Revenge of the Sith</td>
      <td>Star Wars: Episode IV  A New Hope</td>
      <td>Star Wars: Episode V The Empire Strikes Back</td>
      <td>Star Wars: Episode VI Return of the Jedi</td>
      <td>5</td>
      <td>...</td>
      <td>Very favorably</td>
      <td>I don't understand this question</td>
      <td>No</td>
      <td>NaN</td>
      <td>Yes</td>
      <td>Male</td>
      <td>18-29</td>
      <td>$100,000 - $149,999</td>
      <td>Some college or Associate degree</td>
      <td>West North Central</td>
    </tr>
    <tr>
      <th>5</th>
      <td>3292731220</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>Star Wars: Episode I  The Phantom Menace</td>
      <td>Star Wars: Episode II  Attack of the Clones</td>
      <td>Star Wars: Episode III  Revenge of the Sith</td>
      <td>Star Wars: Episode IV  A New Hope</td>
      <td>Star Wars: Episode V The Empire Strikes Back</td>
      <td>Star Wars: Episode VI Return of the Jedi</td>
      <td>5</td>
      <td>...</td>
      <td>Somewhat favorably</td>
      <td>Greedo</td>
      <td>Yes</td>
      <td>No</td>
      <td>No</td>
      <td>Male</td>
      <td>18-29</td>
      <td>$100,000 - $149,999</td>
      <td>Some college or Associate degree</td>
      <td>West North Central</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 38 columns</p>
</div>



# Converting to Boolean Data Type


```python
bool_dict = {"Yes": True, "No": False, np.nan: False}

star_wars["Have you seen any of the 6 films in the Star Wars franchise?"].map(bool_dict)
star_wars["Do you consider yourself to be a fan of the Star Wars film franchise?"].map(bool_dict)
print(star_wars["Have you seen any of the 6 films in the Star Wars franchise?"].unique())
print(star_wars["Do you consider yourself to be a fan of the Star Wars film franchise?"].unique())
```

    ['Yes' 'No' ' Inc.' nan]
    ['Yes' nan 'No']
    

# Change Views Movies Column Names 


```python
column_names = star_wars.columns.values
for each in range(3,9):
    column_names[each] = "seen_" + str(each-2)
star_wars.columns = column_names

star_wars.columns
```




    Index(['RespondentID',
           'Have you seen any of the 6 films in the Star Wars franchise?',
           'Do you consider yourself to be a fan of the Star Wars film franchise?',
           'seen_1', 'seen_2', 'seen_3', 'seen_4', 'seen_5', 'seen_6',
           'Please rank the Star Wars films in order of preference with 1 being your favorite film in the franchise and 6 being your least favorite film.',
           'Unnamed: 10', 'Unnamed: 11', 'Unnamed: 12', 'Unnamed: 13',
           'Unnamed: 14',
           'Please state whether you view the following characters favorably, unfavorably, or are unfamiliar with him/her.',
           'Unnamed: 16', 'Unnamed: 17', 'Unnamed: 18', 'Unnamed: 19',
           'Unnamed: 20', 'Unnamed: 21', 'Unnamed: 22', 'Unnamed: 23',
           'Unnamed: 24', 'Unnamed: 25', 'Unnamed: 26', 'Unnamed: 27',
           'Unnamed: 28', 'Which character shot first?',
           'Are you familiar with the Expanded Universe?',
           'Do you consider yourself to be a fan of the Expanded Universe?æ',
           'Do you consider yourself to be a fan of the Star Trek franchise?',
           'Gender', 'Age', 'Household Income', 'Education',
           'Location (Census Region)'],
          dtype='object')



# Converting Movie Response to Boolean Type


```python
movies = {
    "Star Wars: Episode I  The Phantom Menace": True, 
    np.nan: False, 
    "Star Wars: Episode II  Attack of the Clones": True,
    "Star Wars: Episode III  Revenge of the Sith": True,
    "Star Wars: Episode IV  A New Hope": True,
    "Star Wars: Episode V The Empire Strikes Back": True,
    "Star Wars: Episode VI Return of the Jedi": True
}

for cols in star_wars.columns[3:9]:
    star_wars[cols] = star_wars[cols].map(movies)

star_wars[3:9].head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RespondentID</th>
      <th>Have you seen any of the 6 films in the Star Wars franchise?</th>
      <th>Do you consider yourself to be a fan of the Star Wars film franchise?</th>
      <th>seen_1</th>
      <th>seen_2</th>
      <th>seen_3</th>
      <th>seen_4</th>
      <th>seen_5</th>
      <th>seen_6</th>
      <th>Please rank the Star Wars films in order of preference with 1 being your favorite film in the franchise and 6 being your least favorite film.</th>
      <th>...</th>
      <th>Unnamed: 28</th>
      <th>Which character shot first?</th>
      <th>Are you familiar with the Expanded Universe?</th>
      <th>Do you consider yourself to be a fan of the Expanded Universe?æ</th>
      <th>Do you consider yourself to be a fan of the Star Trek franchise?</th>
      <th>Gender</th>
      <th>Age</th>
      <th>Household Income</th>
      <th>Education</th>
      <th>Location (Census Region)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>4</th>
      <td>3292763116</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>5</td>
      <td>...</td>
      <td>Very favorably</td>
      <td>I don't understand this question</td>
      <td>No</td>
      <td>NaN</td>
      <td>Yes</td>
      <td>Male</td>
      <td>18-29</td>
      <td>$100,000 - $149,999</td>
      <td>Some college or Associate degree</td>
      <td>West North Central</td>
    </tr>
    <tr>
      <th>5</th>
      <td>3292731220</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>5</td>
      <td>...</td>
      <td>Somewhat favorably</td>
      <td>Greedo</td>
      <td>Yes</td>
      <td>No</td>
      <td>No</td>
      <td>Male</td>
      <td>18-29</td>
      <td>$100,000 - $149,999</td>
      <td>Some college or Associate degree</td>
      <td>West North Central</td>
    </tr>
    <tr>
      <th>6</th>
      <td>3292719380</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>1</td>
      <td>...</td>
      <td>Very favorably</td>
      <td>Han</td>
      <td>Yes</td>
      <td>No</td>
      <td>Yes</td>
      <td>Male</td>
      <td>18-29</td>
      <td>$25,000 - $49,999</td>
      <td>Bachelor degree</td>
      <td>Middle Atlantic</td>
    </tr>
    <tr>
      <th>7</th>
      <td>3292684787</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>6</td>
      <td>...</td>
      <td>Very favorably</td>
      <td>Han</td>
      <td>Yes</td>
      <td>No</td>
      <td>No</td>
      <td>Male</td>
      <td>18-29</td>
      <td>NaN</td>
      <td>High school degree</td>
      <td>East North Central</td>
    </tr>
    <tr>
      <th>8</th>
      <td>3292663732</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>4</td>
      <td>...</td>
      <td>Very favorably</td>
      <td>Han</td>
      <td>No</td>
      <td>NaN</td>
      <td>Yes</td>
      <td>Male</td>
      <td>18-29</td>
      <td>NaN</td>
      <td>High school degree</td>
      <td>South Atlantic</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 38 columns</p>
</div>



# Change Movie Ranking Columns Names


```python
column_names = star_wars.columns.values
for i in range(9, 15):
    column_names[i] = "ranking_" + str(i-8)
star_wars.columns = column_names

print(star_wars.columns[9:15])
```

    Index(['ranking_1', 'ranking_2', 'ranking_3', 'ranking_4', 'ranking_5',
           'ranking_6'],
          dtype='object')
    

# Change Movie Ranking Columns Data Type


```python
star_wars[star_wars.columns[9:15]] = star_wars[star_wars.columns[9:15]].astype(float)
print(star_wars["ranking_6"].dtype)
```

    float64
    

# Plot Average Ranking of Movies


```python
cols = star_wars.columns[9:15]
bar_heights = star_wars[cols].mean()
print("Average Movie Rankings\n", bar_heights)
```

    Average Movie Rankings
     ranking_1    3.732934
    ranking_2    4.087321
    ranking_3    4.341317
    ranking_4    3.272727
    ranking_5    2.513158
    ranking_6    3.047847
    dtype: float64
    


```python
import matplotlib.pyplot as plt
%matplotlib inline

fig, ax = plt.subplots()
bar_positions = range(1,7)

ax.set_xlim(0,7)
ax.bar(bar_positions, bar_heights, 0.40, align="center")
ax.set_xticks(range(1,7))
ax.set_xticklabels(cols, rotation=90)
ax.set_xlabel("Movie Names")
ax.set_title("Movie Average Rankings")    
```




    Text(0.5,1,'Movie Average Rankings')




![png](output_16_1.png)


# Report Number of Movies Seen


```python
col = star_wars.columns[3:9]
print(star_wars[col].sum())
```

    seen_1    673
    seen_2    571
    seen_3    550
    seen_4    607
    seen_5    758
    seen_6    738
    dtype: int64
    

# Plot Number of Movies Seen


```python
cols = star_wars.columns[3:9].values

fig, ax = plt.subplots()
ax.bar(range(1,7), star_wars[cols].sum(), 0.5, align="center")
ax.set_xticks(range(1,7))
ax.set_xticklabels(cols, rotation=90)
ax.set_xlabel("Movies Seen")
ax.set_title("Frequency of Movie Viewes")
```




    Text(0.5,1,'Frequency of Movie Viewes')




![png](output_20_1.png)


# Split Database into Male & Female Groups


```python
males = star_wars[star_wars["Gender"] == "Male"]
females = star_wars[star_wars["Gender"] == "Female"]
print(males["Gender"].head())
print(females["Gender"].head())
```

    1    Male
    2    Male
    3    Male
    4    Male
    5    Male
    Name: Gender, dtype: object
    112    Female
    113    Female
    115    Female
    117    Female
    118    Female
    Name: Gender, dtype: object
    

# Report # of Movies Seen by Males


```python
print(males[cols].sum())
```

    seen_1    361
    seen_2    323
    seen_3    317
    seen_4    342
    seen_5    392
    seen_6    387
    dtype: int64
    

# Plot # of Movies Seen by Males


```python
fig, ax = plt.subplots()
ax.bar(range(1,7), males[cols].sum(), 0.5, align="center")
ax.set_xticks(range(1,7))
ax.set_xticklabels(cols, rotation=90)
ax.set_xlabel("Movies Seen by Males")
ax.set_title("Frequency of Movie Viewed by Males")
```




    Text(0.5,1,'Frequency of Movie Viewed by Males')




![png](output_26_1.png)


# Report # of Movies Seen by Females


```python
print(females[cols].sum())
```

    seen_1    298
    seen_2    237
    seen_3    222
    seen_4    255
    seen_5    353
    seen_6    338
    dtype: int64
    

# Plot # of Movies Seen by Females


```python
fig, ax = plt.subplots()
ax.bar(range(1,7), females[cols].sum(), 0.5, align="center")
ax.set_xticks(range(1,7))
ax.set_xticklabels(cols, rotation=90)
ax.set_xlabel("Movies Seen by Females")
ax.set_title("Frequency of Movie Viewed by Female")
```




    Text(0.5,1,'Frequency of Movie Viewed by Female')




![png](output_30_1.png)


# Plot Average Movie Rankings by Males


```python
cols = star_wars.columns[9:15].values
print( males[cols].mean())
```

    ranking_1    4.037825
    ranking_2    4.224586
    ranking_3    4.274882
    ranking_4    2.997636
    ranking_5    2.458629
    ranking_6    3.002364
    dtype: float64
    


```python
fig, ax = plt.subplots()
ax.bar(range(1,7), males[cols].mean(), 0.40, align="center")
ax.set_xticks(range(1,7))
ax.set_xticklabels(cols, rotation=90)
ax.set_xlabel("Movie Names")
ax.set_title("Movie Average Rankings by Males")   
```




    Text(0.5,1,'Movie Average Rankings by Males')




![png](output_33_1.png)


# Plot Average Movie Rankings by Females


```python
print(females[cols].mean())
```

    ranking_1    3.429293
    ranking_2    3.954660
    ranking_3    4.418136
    ranking_4    3.544081
    ranking_5    2.569270
    ranking_6    3.078086
    dtype: float64
    


```python
fig, ax = plt.subplots()
ax.bar(range(1,7), females[cols].mean(), 0.40, align="center")
ax.set_xticks(range(1,7))
ax.set_xticklabels(cols, rotation=90)
ax.set_xlabel("Movie Names")
ax.set_title("Movie Average Rankings by Females")   
```




    Text(0.5,1,'Movie Average Rankings by Females')




![png](output_36_1.png)


## Finding the Characters' Preference Pattern


```python
print(star_wars['Please state whether you view the following characters favorably, unfavorably, or are unfamiliar with him/her.'].unique())
```

    ['Very favorably' nan 'Somewhat favorably'
     'Neither favorably nor unfavorably (neutral)' 'Somewhat unfavorably'
     'Unfamiliar (N/A)' 'Very unfavorably']
    

## Providing Character Rating Column Names


```python
cols = star_wars.columns.values
for i in range(15,29):
    cols[i] = "character_" + str(i-14)
star_wars.columns = cols
print(star_wars.columns[15:29])
print(star_wars['character_5'].unique())
```

    Index(['character_1', 'character_2', 'character_3', 'character_4',
           'character_5', 'character_6', 'character_7', 'character_8',
           'character_9', 'character_10', 'character_11', 'character_12',
           'character_13', 'character_14'],
          dtype='object')
    ['Very favorably' nan 'Somewhat favorably' 'Very unfavorably'
     'Neither favorably nor unfavorably (neutral)' 'Somewhat unfavorably'
     'Unfamiliar (N/A)']
    

## Filtering the Character Rating Column Responses


```python
cols = star_wars.columns[15:29].values
for col in cols:
    star_wars[col] = star_wars[~star_wars[col].isin(['Unfamiliar (N/A)'])][col]
    star_wars = star_wars.dropna(subset=[col])
```

## Setup the Voting Index based on the Character Ranking


```python
# Assigning voting map based on the level of likes/dislikes
char_map = {
    'Very favorably': 2,
    'Somewhat favorably': 1,
    'Neither favorably nor unfavorably (neutral)': 0,
    'Somewhat unfavorably': -1,
    'Very unfavorably': -2,
}

for i in star_wars.columns[15:29]:
    star_wars[i] = star_wars[i].map(char_map)
star_wars.iloc[:,15:29].head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>character_1</th>
      <th>character_2</th>
      <th>character_3</th>
      <th>character_4</th>
      <th>character_5</th>
      <th>character_6</th>
      <th>character_7</th>
      <th>character_8</th>
      <th>character_9</th>
      <th>character_10</th>
      <th>character_11</th>
      <th>character_12</th>
      <th>character_13</th>
      <th>character_14</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>4</th>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>-1</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>5</th>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>-1</td>
      <td>2</td>
      <td>-2</td>
      <td>1</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>-2</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>6</th>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>7</th>
      <td>2</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>1</td>
      <td>2</td>
      <td>-1</td>
      <td>1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>8</th>
      <td>2</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
      <td>-2</td>
      <td>-1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>-2</td>
      <td>-1</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>



## Segregatting Respondents Voting Preferences


```python
for i in range(2):
    for col in cols:
        if i == 0:
            star_wars[col + str("_likes")] = star_wars[star_wars[col] > 0][col]
        else:
            star_wars[col + str("_dislikes")] = star_wars[star_wars[col] <= 0][col]
            
print(star_wars.columns[38:68])
```

    Index(['character_1_likes', 'character_2_likes', 'character_3_likes',
           'character_4_likes', 'character_5_likes', 'character_6_likes',
           'character_7_likes', 'character_8_likes', 'character_9_likes',
           'character_10_likes', 'character_11_likes', 'character_12_likes',
           'character_13_likes', 'character_14_likes', 'character_1_dislikes',
           'character_2_dislikes', 'character_3_dislikes', 'character_4_dislikes',
           'character_5_dislikes', 'character_6_dislikes', 'character_7_dislikes',
           'character_8_dislikes', 'character_9_dislikes', 'character_10_dislikes',
           'character_11_dislikes', 'character_12_dislikes',
           'character_13_dislikes', 'character_14_dislikes'],
          dtype='object')
    

## Respondents "Like" Response for Characters


```python
print(star_wars.iloc[:,38:52].sum().sort_values(ascending=False))
```

    character_1_likes     872.0
    character_5_likes     860.0
    character_14_likes    856.0
    character_2_likes     831.0
    character_3_likes     821.0
    character_11_likes    806.0
    character_10_likes    730.0
    character_7_likes     557.0
    character_4_likes     509.0
    character_13_likes    383.0
    character_8_likes     380.0
    character_9_likes     350.0
    character_6_likes     311.0
    character_12_likes    235.0
    dtype: float64
    

## Respondents "Dislike" Response for Characters


```python
print(star_wars.iloc[:,52:69].sum().sort_values())
```

    character_12_dislikes   -392.0
    character_6_dislikes    -241.0
    character_7_dislikes    -199.0
    character_9_dislikes    -122.0
    character_4_dislikes    -110.0
    character_13_dislikes   -106.0
    character_8_dislikes     -56.0
    character_10_dislikes    -26.0
    character_11_dislikes    -17.0
    character_5_dislikes     -16.0
    character_14_dislikes    -16.0
    character_3_dislikes     -14.0
    character_2_dislikes     -12.0
    character_1_dislikes      -8.0
    dtype: float64
    

## Plot of Respondents' Character Preference Pattern


```python
col_like = star_wars.columns[38:52].values
col_dislike = star_wars.columns[52:69].values
char_names = star_wars.columns[15:29].values
bar_height_like = star_wars[col_like].sum()
bar_height_dislike = star_wars[col_dislike].sum()
  
fig, ax = plt.subplots()
ax.bar(range(1,15), bar_height_like, 0.40, align="center", color="blue")
ax.bar(range(1,15), bar_height_dislike, 0.40, align="center", color='red')
ax.set_xticks(range(1,15))
ax.set_xticklabels(char_names, rotation=90)
ax.set_xlabel("Character Names")
ax.set_ylabel("Voting Index")
ax.set_title("Characters Popularity") 
plt.show()
```


![png](output_52_0.png)


## Male Respondents' "Like" Response for Characters


```python
col_like = list(star_wars.columns[38:52])
male_char_like = star_wars[star_wars["Gender"] == "Male"][col_like]
print(male_char_like.sum().sort_values(ascending=False))
```

    character_1_likes     507.0
    character_5_likes     494.0
    character_2_likes     480.0
    character_14_likes    478.0
    character_3_likes     470.0
    character_11_likes    434.0
    character_10_likes    383.0
    character_7_likes     348.0
    character_4_likes     270.0
    character_9_likes     226.0
    character_8_likes     226.0
    character_13_likes    217.0
    character_6_likes     201.0
    character_12_likes    111.0
    dtype: float64
    

## Male Respondents' "Dislike" Response for Characters


```python
col_dislike = list(star_wars.columns[52:69])
male_char_dislike = star_wars[star_wars["Gender"] == "Male"][col_dislike]
print(male_char_dislike.sum().sort_values())
```

    character_12_dislikes   -262.0
    character_6_dislikes    -129.0
    character_7_dislikes     -90.0
    character_4_dislikes     -74.0
    character_13_dislikes    -69.0
    character_9_dislikes     -66.0
    character_8_dislikes     -36.0
    character_10_dislikes    -22.0
    character_11_dislikes    -13.0
    character_14_dislikes    -12.0
    character_5_dislikes      -9.0
    character_2_dislikes      -7.0
    character_3_dislikes      -7.0
    character_1_dislikes      -6.0
    dtype: float64
    

## Plot of Male Respondents' Character Preference Pattern


```python
bar_height_like = male_char_like.sum()
bar_height_dislike = male_char_dislike.sum()
  
fig, ax = plt.subplots()
ax.bar(range(1,15), bar_height_like, 0.40, align="center", color="yellow")
ax.bar(range(1,15), bar_height_dislike, 0.40, align="center", color='green')
ax.set_xticks(range(1,15))
ax.set_xticklabels(char_names, rotation=90)
ax.set_xlabel("Character Names")
ax.set_ylabel("Voting Index")
ax.set_title("Characters Popularity for Males") 
plt.show()
```


![png](output_58_0.png)


### Female Respondents' "Like" Response for Characters


```python
col_like = list(star_wars.columns[38:52])
female_char_like = star_wars[star_wars["Gender"] == "Female"][col_like]
print(female_char_like.sum().sort_values(ascending=False))
```

    character_14_likes    364.0
    character_11_likes    358.0
    character_5_likes     352.0
    character_1_likes     351.0
    character_2_likes     338.0
    character_3_likes     337.0
    character_10_likes    333.0
    character_4_likes     224.0
    character_7_likes     200.0
    character_13_likes    156.0
    character_8_likes     147.0
    character_12_likes    119.0
    character_9_likes     115.0
    character_6_likes     100.0
    dtype: float64
    

### Female Respondents' "Dislike" Response for Characters


```python
col_dislike = list(star_wars.columns[52:69])
female_char_dislike = star_wars[star_wars["Gender"] == "Female"][col_dislike]
print(female_char_dislike.sum().sort_values())
```

    character_12_dislikes   -125.0
    character_6_dislikes    -110.0
    character_7_dislikes    -105.0
    character_9_dislikes     -55.0
    character_4_dislikes     -36.0
    character_13_dislikes    -36.0
    character_8_dislikes     -20.0
    character_3_dislikes      -6.0
    character_5_dislikes      -6.0
    character_2_dislikes      -4.0
    character_14_dislikes     -4.0
    character_10_dislikes     -3.0
    character_11_dislikes     -3.0
    character_1_dislikes      -1.0
    dtype: float64
    

### Plot of Female Respondents' Character Preference Pattern


```python
bar_height_like = female_char_like.sum()
bar_height_dislike = female_char_dislike.sum()
  
fig, ax = plt.subplots()
ax.bar(range(1,15), bar_height_like, 0.40, align="center", color="black")
ax.bar(range(1,15), bar_height_dislike, 0.40, align="center", color='grey')
ax.set_xticks(range(1,15))
ax.set_xticklabels(char_names, rotation=90)
ax.set_xlabel("Character Names")
ax.set_ylabel("Voting Index")
ax.set_title("Characters Popularity for Females") 
plt.show()
```


![png](output_64_0.png)


## Conclusion about favorite Star Wars movies
1. Earlier movies appear to be more popular since the respondents tend to see more original movies than the new movies. 
2. On an average more males watched the scenes 1 thru 3 than the female. However, females liked episodes_3 more than the males.
3. The respondents overall like character_1 the most followed by the character_5 and character_14.
4. The respondents overall dislike character_12 the most followed by the character_6 and character_7.
5. The average weightage of women's characters preference is around 72% that of male's characters preference. 
6. Considering thin marginal spread between the likes and dislikes for character_6; respondents' preference for this character appear to be controversial.